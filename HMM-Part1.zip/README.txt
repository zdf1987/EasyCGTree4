**Prokaryote****
1. rp1, 16 ubiquitous ribosomal protein genes (18 domains) in Prokaryote.(http://dx.doi.org/10.1038/nature14486)
2. rp2, 23 ubiquitous ribosomal protein genes (27 domains) in Prokaryote.(http://dx.doi.org/10.1038/nature12352)

**Bacteria***
1. bac120, 120 ubiquitous genes in the domain Bacteria.(http://dx.doi.org/10.1038/s41564-017-0012-7)
2. essential, 107 essential single-copy core genes in Bacteria. (https://cdnsciencepub.com/doi/10.1139/gen-2015-0175)
3. ubcg1, 92 core genes named as up-to-date bacterial core gene. (http://dx.doi.org/10.1007/s12275-018-8014-6)
4. ubcg2，81 core genes named as up-to-date bacterial core gene. (https://doi.org/10.1007/s12275-021-1231-4)
5. bac52, 52 ubiquitous ribosomal protein genes in Bacteria.(https://www.kegg.jp/kegg/annotation/br01610.html)

**Archaea***
1. ar122, 122 ubiquitous genes in the domain Archaea.(http://dx.doi.org/10.1038/s41564-017-0012-7)
2. uacg, 128 ubiquitous genes in the domain Archaea. (https://link.springer.com/article/10.1007/s12275-023-00064-2)
3. ar53, 52 ubiquitous ribosomal protein genes in Archaea.(https://www.kegg.jp/kegg/annotation/br01610.html)

**Others***
1. AXT，the five key genes for astaxanthin synthesis in Prokartotes.(https://doi.org/10.1016/j.syapm.2025.126624)
2. CKC20, 20 core genes distinguishable among Corynebact erium kroppenst edtii complex (CKC). (https://doi.org/10.1093/jambio/lxad314)
3. ery288, 288 core genes of the family Erythrobacteraceae.(http://dx.doi.org/10.1099/ijsem.0.004293)
4. rhodo268, 268 core genes of the family Rhodobacteraceae.(https://doi.org/10.1099/ijsem.0.006156)
5. spi269, 269 core genes of the family Spirosomaceae. (https://doi.org/10.1007/s12275-022-2102-3)

